// Copyright (c) ONNX Project Contributors.
// Licensed under the MIT license.

#pragma once

#define ONNX_UNUSED_PARAMETER(x) (void)(x)
