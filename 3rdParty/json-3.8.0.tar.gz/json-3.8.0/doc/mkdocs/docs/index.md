# JSON for Modern C++

!!! note
    
    This page is under construction. You probably want to see the [Doxygen documentation](doxygen).

![](images/json.gif)
