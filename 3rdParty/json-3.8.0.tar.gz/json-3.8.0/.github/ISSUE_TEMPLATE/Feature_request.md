---
name: Feature request
about: Suggest an idea for this project
title: ''
labels: 'kind: enhancement/improvement'
assignees: ''

---

#### Which feature do you want to see in the library?

<!-- Describe the feature in as much detail as possible. -->

#### How would the feature be usable for other users?

<!-- Include sample usage where appropriate. -->
