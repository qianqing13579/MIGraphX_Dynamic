---
name: Feature request
about: Suggest a new feature for this project
title: ''
labels: feature
assignees: ''

---
<!-- Describe below how you want ccache to work or behave: -->

