---
name: Improvement
about: Suggest an improvement that is neither a bug fix nor a new feature
title: ''
labels: improvement
assignees: ''

---
### Description ###
<!-- Please describe your improvement suggestion below: -->

